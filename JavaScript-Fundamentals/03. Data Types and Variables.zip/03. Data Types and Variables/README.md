Data types and Variables
========================

### Problem 1. JavaScript literals
*	Assign all the possible JavaScript literals to different variables.

### Problem 2. Quoted text
*	Create a string variable with quoted text in it.
*	For example: `'How you doin'?', Joey said'.

### Problem 3. Typeof variables
*	Try typeof on all variables you created.

### Problem 4. Typeof null
*	Create null, undefined variables and try typeof on them.
